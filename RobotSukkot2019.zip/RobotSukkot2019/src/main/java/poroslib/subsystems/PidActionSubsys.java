package poroslib.subsystems;

import edu.wpi.first.wpilibj.command.Subsystem;

public interface PidActionSubsys 
{
	public void StopSystem();
		
	public Subsystem GetSubsystem();
}
