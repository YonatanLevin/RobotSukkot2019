package poroslib.sensors;

public interface LimitSensor 
{
	SysPosition GetPosition();
}
