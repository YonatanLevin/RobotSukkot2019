package poroslib.sensors;

public enum SysPosition
{
	Top,
	Bottom,
	Free,
	Blocked
}

